package com.pss.project;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Detail2 extends Activity{
	Dbadapter db=new Dbadapter(this);
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail2);
		Log.d("test", "detail activity entered");
		TextView t1=(TextView) findViewById(R.id.pay);
		db.open();
		String a=db.getAllPayment();
		Log.d("test", "returned");
		db.close();
		Log.d("test", "data taken");
		t1.setText(a);
	}

}
