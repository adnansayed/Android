package com.pss.project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Detail1 extends Activity{
	
Dbadapter db=new Dbadapter(this);
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.detail1);
	Log.d("test", "detail activity entered");
	db.open();
	String a=db.getAllPurchase();
	String[] lines = a.split("\n");
	ListView lv = (ListView)findViewById(R.id.listView1);
	List<String> list = new ArrayList<String>();
	list.addAll(Arrays.asList(lines));
	ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1,list);
	lv.setAdapter(adapter);
	db.close();
	Log.d("test", "data taken");
	
	//SimpleCursorAdapter mc=new SimpleCursorAdapter();
	
}
}
