/** Automatically generated file. DO NOT MODIFY */
package com.pss.project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}