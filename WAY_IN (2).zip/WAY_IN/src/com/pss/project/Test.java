package com.pss.project;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TableRow.LayoutParams;

public class Test extends Activity {
	String bbb;
	TableLayout table_layout;
	EditText rowno_et, colno_et;
	Button build_btn;
	Cursor c;
	Dbadapter db=new Dbadapter(this);
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.test);
		/*rowno_et = (EditText) findViewById(R.id.rowno_id);
		colno_et = (EditText) findViewById(R.id.colno_id);*/
		table_layout = (TableLayout) findViewById(R.id.tableLayout1);
		db.open();
		c = db.readentry();
		int rows = c.getCount();
		int cols = c.getColumnCount();
        Log.d("test", "Value: " + c.getCount());
        Log.d("test", "Value: " + c.getColumnCount());
		table_layout.removeAllViews();
		BuildTable(rows, cols);
		
		//build_btn = (Button) findViewById(R.id.build_btn_id);
		
		
        
		/*build_btn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String rowstring = rowno_et.getText().toString();
				String colstring = colno_et.getText().toString();

				if (!rowstring.equals("") && !colstring.equals("")) {
					c.moveToFirst();
					int rows = c.getCount();
					int cols = c.getColumnCount();
			        Log.d("test", "Value: " + c.getCount());
			        Log.d("test", "Value: " + c.getColumnCount());
					table_layout.removeAllViews();
					BuildTable(rows, cols);
				}

				else {
					Toast.makeText(Test.this,
							"Please Enter the row and col Numbers",
							Toast.LENGTH_SHORT).show();
				}

			}
		});*/

}
	private void BuildTable(int rows, int cols) {
		c.moveToFirst();

		// outer for loop
		for (int i = 1; i <= rows; i++) {

			TableRow row = new TableRow(this);
			row.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
					LayoutParams.WRAP_CONTENT));

			// inner for loop
			for (int j = 1; j < cols; j++) {

				TextView tv = new TextView(this);
				tv.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,
						LayoutParams.WRAP_CONTENT));
				tv.setBackgroundResource(R.drawable.cell_shape);
				tv.setPadding(5, 5, 5, 5);
				bbb=c.getString(j);
				tv.setText(bbb);
				Log.d("test", "Value: " + bbb);
				row.addView(tv);

			}
			c.moveToNext();
			table_layout.addView(row);

		}
	}

	

}
